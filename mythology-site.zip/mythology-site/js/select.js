/* ============================================================
   第二页 · 神话人物馆：用户名显示 / 退出登录 / 快捷跳转
   ------------------------------------------------------------
   页面里的 onclick="logout()" 需要这个全局函数。
   ============================================================ */
(function () {
    'use strict';

    /* 六位人物：与页面上的按钮顺序一致 */
    var PAGES = [
        'nezha.html',
        'wukong.html',
        'yangjian.html',
        'change.html',
        'kuafu.html',
        'jingwei.html'
    ];

    /* 当前登录用户 */
    var info = document.getElementById('userInfo');
    var user = (window.MythoAuth && window.MythoAuth.getUser()) || '';
    if (info) {
        info.textContent = user ? '欢迎：' + user : '';
    }

    /* 退出登录：清掉登录态，回登录页 */
    function logout() {
        if (window.MythoAuth) {
            window.MythoAuth.logout();
        } else {
            try {
                window.localStorage.removeItem('loginUser');
            } catch (e) { /* noop */ }
        }
        window.location.href = 'login.html';
    }

    window.logout = logout;

    /* 数字键 1-6 直达对应人物 */
    document.addEventListener('keydown', function (e) {
        if (e.key >= '1' && e.key <= '6') {
            var idx = Number(e.key) - 1;
            if (PAGES[idx]) window.location.href = PAGES[idx];
        }
    });

    /* 光标停在卡片上时，回车 / 空格也能进入 */
    var cards = document.querySelectorAll('.char-card');
    Array.prototype.forEach.call(cards, function (card) {
        card.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                card.click();
            }
        });
    });
})();
