/* ============================================================
   登录状态（前端门禁）
   ------------------------------------------------------------
   存储约定与项目原有登录页保持一致：
     localStorage.userList  —— { "用户名": "密码" }   注册的账号表
     localStorage.loginUser —— "当前登录的用户名"     登录态
   其余页面在 <head> 里调用 MythoAuth.require() 做拦截。
   ============================================================ */
(function () {
    'use strict';

    var KEY_LIST = 'userList';
    var KEY_USER = 'loginUser';
    var KEY_LEGACY = 'mytho.auth.v1'; // 旧版标记，进来就顺手清掉

    function safeGet(key) {
        try {
            return window.localStorage.getItem(key);
        } catch (e) {
            return null;
        }
    }

    function safeSet(key, val) {
        try {
            window.localStorage.setItem(key, val);
            return true;
        } catch (e) {
            return false;
        }
    }

    // 清掉历史遗留标记，避免和 loginUser 打架
    try {
        if (window.localStorage.getItem(KEY_LEGACY)) {
            window.localStorage.removeItem(KEY_LEGACY);
        }
    } catch (e) { /* noop */ }

    var Auth = {
        /** 是否已登录 */
        isLoggedIn: function () {
            return !!safeGet(KEY_USER);
        },

        /** 当前登录用户名，未登录返回 '' */
        getUser: function () {
            return safeGet(KEY_USER) || '';
        },

        /** 读取已注册账号表 */
        getUsers: function () {
            try {
                return JSON.parse(safeGet(KEY_LIST) || '{}') || {};
            } catch (e) {
                return {};
            }
        },

        /**
         * 写入登录态
         * @returns {boolean} 是否写入成功（隐私模式等会失败）
         */
        login: function (name) {
            return safeSet(KEY_USER, name || '');
        },

        /** 退出登录 */
        logout: function () {
            try {
                window.localStorage.removeItem(KEY_USER);
            } catch (e) { /* noop */ }
        },

        /** 页面守卫：未登录则跳转到登录页 */
        require: function () {
            if (Auth.isLoggedIn()) return true;
            window.location.replace('login.html');
            return false;
        }
    };

    window.MythoAuth = Auth;
})();
