/* ============================================================
   首页交互：关于弹层 / 退出确认
   ============================================================ */
(function () {
    /* 底部显示当前登录用户 */
    const whoami = document.getElementById('whoami');
    if (whoami && window.MythoAuth && window.MythoAuth.isLoggedIn()) {
        whoami.textContent = '已登录：' + window.MythoAuth.getUser();
    }

    const startBtn = document.getElementById('startBtn');
    const aboutBtn = document.getElementById('aboutBtn');
    const exitBtn = document.getElementById('exitBtn');

    const aboutOverlay = document.getElementById('aboutOverlay');
    const exitOverlay = document.getElementById('exitOverlay');

    /* ---------- 弹层开关 ---------- */
    function openOverlay(el) {
        if (!el) return;
        el.classList.add('open');
        const focusTarget = el.querySelector('.btn-mini');
        if (focusTarget) focusTarget.focus();
    }

    function closeOverlay(el) {
        if (!el) return;
        el.classList.remove('open');
    }

    document.querySelectorAll('[data-close]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            closeOverlay(btn.closest('.overlay'));
        });
    });

    // 点击遮罩空白处关闭
    [aboutOverlay, exitOverlay].forEach(function (ov) {
        if (!ov) return;
        ov.addEventListener('click', function (e) {
            if (e.target === ov) closeOverlay(ov);
        });
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeOverlay(aboutOverlay);
            closeOverlay(exitOverlay);
        }
    });

    /* ---------- 开始探索 ---------- */
    if (startBtn) {
        startBtn.addEventListener('click', function () {
            startBtn.disabled = true;
            startBtn.style.opacity = '0.7';
            document.body.style.transition = 'opacity .38s ease';
            document.body.style.opacity = '0';
            setTimeout(function () {
                window.location.href = 'characters.html';
            }, 360);
        });
    }

    /* ---------- 关于本志 ---------- */
    if (aboutBtn) {
        aboutBtn.addEventListener('click', function () {
            openOverlay(aboutOverlay);
        });
    }

    /* ---------- 退出 ---------- */
    if (exitBtn) {
        exitBtn.addEventListener('click', function () {
            openOverlay(exitOverlay);
        });
    }

    const exitConfirm = document.getElementById('exitConfirm');
    if (exitConfirm) {
        exitConfirm.addEventListener('click', function () {
            closeOverlay(exitOverlay);
            window.close();
            // 本地直接打开 html 时，浏览器安全策略会拦截 window.close()
            setTimeout(function () {
                if (!document.hidden) {
                    document.body.innerHTML =
                        '<div style="min-height:100vh;display:flex;flex-direction:column;' +
                        'align-items:center;justify-content:center;gap:18px;text-align:center;' +
                        'color:#efe9de;background:#0a0a12;font-family:KaiTi,STKaiti,serif">' +
                        '<div style="font-size:56px;letter-spacing:10px;text-indent:10px;color:#ff4747;' +
                        'text-shadow:0 0 20px rgba(255,51,51,.8)">珍重</div>' +
                        '<div style="font-size:15px;letter-spacing:3px;color:#9a93a8">' +
                        '已退出「上古纪事」· 可直接关闭此页面</div></div>';
                }
            }, 260);
        });
    }

    /* ---------- 退出登录 ---------- */
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function () {
            if (window.MythoAuth) window.MythoAuth.logout();
            window.location.replace('login.html');
        });
    }

    /* ---------- 首页人物剪影：点击直达对应人物故事页 ---------- */
    const TALE_PAGES = {
        nezha: 'nezha.html',
        wukong: 'wukong.html',
        erlang: 'yangjian.html',
        change: 'change.html',
        kuafu: 'kuafu.html',
        jingwei: 'jingwei.html'
    };

    document.querySelectorAll('.roster-strip img').forEach(function (img) {
        img.style.cursor = 'pointer';
        img.addEventListener('click', function () {
            const page = TALE_PAGES[img.dataset.id] || ('story.html?c=' + encodeURIComponent(img.dataset.id));
            window.location.href = page;
        });
    });
})();
