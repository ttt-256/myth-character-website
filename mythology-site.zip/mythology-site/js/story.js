/* ============================================================
   人物对话页 · 核心逻辑
   功能：
     1. 左侧人物名录切换（6 位）
     2. 台词逐字打字机显示
     3. 语音朗读（Web Speech API，中文音色）
     4. 上一句 / 下一句 / 重播 / 自动连播
     5. 键盘快捷键
   ============================================================ */
(function () {
    'use strict';

    const $ = function (id) { return document.getElementById(id); };

    /* ---------------- 状态 ---------------- */
    let charIndex = 0;          // 当前人物
    let lineIndex = 0;          // 当前台词
    let typeTimer = null;       // 打字机定时器
    let advanceTimer = null;    // 自动连播定时器
    let isTyping = false;       // 是否正在逐字显示
    let voiceOn = true;         // 语音朗读开关
    let autoPlay = false;       // 自动连播开关
    let speed = 1.0;            // 朗读语速
    let speechToken = 0;        // 语音回调令牌（防止串台）
    let zhVoice = null;         // 中文音色缓存
    let gestureReady = false;   // 用户是否已与页面交互过

    const SPEEDS = [
        { value: 0.8, label: '慢' },
        { value: 1.0, label: '中' },
        { value: 1.25, label: '快' }
    ];

    /* ---------------- 音色准备 ---------------- */
    function pickVoice() {
        if (!('speechSynthesis' in window)) return;
        const voices = window.speechSynthesis.getVoices() || [];
        if (!voices.length) return;
        zhVoice =
            voices.find(function (v) { return /zh[-_]CN/i.test(v.lang); }) ||
            voices.find(function (v) { return /^zh/i.test(v.lang); }) ||
            voices.find(function (v) { return /Chinese|中文|普通话/i.test(v.name); }) ||
            null;
    }

    if ('speechSynthesis' in window) {
        pickVoice();
        window.speechSynthesis.onvoiceschanged = pickVoice;
    }

    /* ---------------- 语音朗读 ---------------- */
    function cancelSpeech() {
        speechToken++; // 让旧回调全部失效
        if (!('speechSynthesis' in window)) return;
        try { window.speechSynthesis.cancel(); } catch (e) { /* noop */ }
    }

    function speak(text, onDone) {
        speechToken++;
        const token = speechToken;

        if (!voiceOn || !('speechSynthesis' in window)) {
            if (onDone) onDone();
            return;
        }

        try { window.speechSynthesis.cancel(); } catch (e) { /* noop */ }

        const u = new SpeechSynthesisUtterance(text);
        u.lang = 'zh-CN';
        u.rate = speed;
        u.pitch = 1.03;
        u.volume = 1;
        if (zhVoice) u.voice = zhVoice;

        const finish = function () {
            if (token !== speechToken) return; // 已被新的朗读取代
            if (onDone) onDone();
        };
        u.onend = finish;
        u.onerror = finish;

        try {
            window.speechSynthesis.speak(u);
        } catch (e) {
            finish();
        }
    }

    /* ---------------- 逐字打字机 ---------------- */
    function stopTyping() {
        if (typeTimer !== null) {
            clearInterval(typeTimer);
            typeTimer = null;
        }
        isTyping = false;
        const el = $('bubbleText');
        if (el) el.classList.remove('typing');
    }

    function typeLine(text, onDone) {
        stopTyping();
        const el = $('bubbleText');
        el.textContent = '';
        el.classList.add('typing');
        isTyping = true;

        let i = 0;
        const delay = Math.max(24, Math.round(78 / speed));

        typeTimer = setInterval(function () {
            i++;
            el.textContent = text.slice(0, i);
            if (i >= text.length) {
                clearInterval(typeTimer);
                typeTimer = null;
                isTyping = false;
                el.classList.remove('typing');
                if (onDone) onDone();
            }
        }, delay);
    }

    /* ---------------- 界面刷新 ---------------- */
    function renderRoster() {
        const box = $('roster');
        box.innerHTML = '<div class="roster-head">人 物 名 录</div>';

        CHARACTERS.forEach(function (ch, i) {
            const btn = document.createElement('button');
            btn.className = 'roster-card';
            btn.type = 'button';
            btn.dataset.index = String(i);
            btn.innerHTML =
                '<img src="' + ch.avatar + '" alt="' + ch.name + '">' +
                '<span class="roster-meta">' +
                '<span class="roster-name">' + ch.name + '</span>' +
                '<span class="roster-title">' + ch.title + '</span>' +
                '</span>';
            btn.addEventListener('click', function () { selectCharacter(i); });
            box.appendChild(btn);
        });
        markActiveRoster();
    }

    function markActiveRoster() {
        const cards = $('roster').querySelectorAll('.roster-card');
        cards.forEach(function (c) {
            c.classList.toggle('active', Number(c.dataset.index) === charIndex);
        });
    }

    function renderStage(ch) {
        const img = $('stageAvatar');
        img.style.animation = 'none';
        void img.offsetWidth; // 强制回流，让入场动画重新播放
        img.src = ch.avatar;
        img.alt = ch.name;
        img.style.animation = '';

        $('stageName').textContent = ch.name;
        $('stageTitle').textContent = ch.title;
        $('stageIntro').textContent = ch.intro || '';

        const tagRow = $('tagRow');
        tagRow.innerHTML = '';
        (ch.tags || []).forEach(function (t) {
            const s = document.createElement('span');
            s.className = 'tag';
            s.textContent = t;
            tagRow.appendChild(s);
        });

        // 主题色光晕
        const wrap = document.querySelector('.avatar-wrap');
        if (wrap) {
            wrap.style.setProperty('--char-color', ch.color || '#ff4747');
            wrap.style.filter = 'drop-shadow(0 0 22px ' + hexToRgba(ch.color, 0.42) + ')';
        }
    }

    function hexToRgba(hex, alpha) {
        if (!hex) return 'rgba(255,71,71,' + alpha + ')';
        let h = hex.replace('#', '');
        if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
        const n = parseInt(h, 16);
        const r = (n >> 16) & 255;
        const g = (n >> 8) & 255;
        const b = n & 255;
        return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
    }

    function renderProgress(ch) {
        const box = $('progress');
        box.innerHTML = '';
        ch.lines.forEach(function (_, i) {
            const d = document.createElement('button');
            d.className = 'dot';
            d.type = 'button';
            d.title = '第 ' + (i + 1) + ' 句';
            d.addEventListener('click', function () { showLine(i); });
            box.appendChild(d);
        });
        const count = document.createElement('span');
        count.className = 'count';
        box.appendChild(count);
        markProgress(ch);
    }

    function markProgress(ch) {
        const dots = $('progress').querySelectorAll('.dot');
        dots.forEach(function (d, i) {
            d.classList.toggle('active', i === lineIndex);
        });
        const count = $('progress').querySelector('.count');
        if (count) {
            count.textContent = (lineIndex + 1) + ' / ' + ch.lines.length;
        }
    }

    function updateButtons() {
        const ch = CHARACTERS[charIndex];
        $('prevBtn').disabled = false;                       // 首句时回退到上一位人物
        $('nextBtn').disabled = false;
        $('nextBtn').textContent = (lineIndex >= ch.lines.length - 1) ? '下一位 →' : '下一句 →';
    }

    /* ---------------- 显示某一句 ---------------- */
    function showLine(index) {
        const ch = CHARACTERS[charIndex];
        const lines = ch.lines;

        lineIndex = Math.max(0, Math.min(lines.length - 1, index));
        const line = lines[lineIndex];

        clearTimeout(advanceTimer);
        advanceTimer = null;
        cancelSpeech();
        stopTyping();

        $('bubbleText').textContent = '';
        $('bubbleNote').textContent = line.note || '';

        updateButtons();
        markProgress(ch);

        const speechAvailable = ('speechSynthesis' in window);
        let typed = false;
        let spoken = (!voiceOn || !speechAvailable);

        function tryAutoAdvance() {
            if (!typed || !spoken) return;
            if (!autoPlay) return;
            advanceTimer = setTimeout(function () {
                if (!autoPlay) return;
                if (lineIndex >= lines.length - 1) {
                    setAutoPlay(false);
                    return;
                }
                showLine(lineIndex + 1);
            }, 950);
        }

        typeLine(line.text, function () {
            typed = true;
            tryAutoAdvance();
        });

        if (voiceOn && speechAvailable) {
            speak(line.text, function () {
                spoken = true;
                tryAutoAdvance();
            });
        }
    }

    /* ---------------- 人物切换 ---------------- */
    function selectCharacter(index, startLine) {
        charIndex = (index + CHARACTERS.length) % CHARACTERS.length;
        const ch = CHARACTERS[charIndex];

        clearTimeout(advanceTimer);
        cancelSpeech();
        stopTyping();

        renderStage(ch);
        markActiveRoster();
        renderProgress(ch);

        try {
            history.replaceState(null, '', '?c=' + ch.id);
        } catch (e) { /* file:// 下可能不支持，忽略 */ }

        showLine(typeof startLine === 'number' ? startLine : 0);

        // 移动端：切换人物后把舞台滚入视野
        if (window.innerWidth <= 980) {
            const stage = document.querySelector('.stage');
            if (stage) stage.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }

    /* ---------------- 前后翻页 ---------------- */
    function goNext() {
        const ch = CHARACTERS[charIndex];
        if (lineIndex < ch.lines.length - 1) {
            showLine(lineIndex + 1);
        } else {
            selectCharacter(charIndex + 1, 0);
        }
    }

    function goPrev() {
        if (lineIndex > 0) {
            showLine(lineIndex - 1);
        } else {
            const prev = (charIndex - 1 + CHARACTERS.length) % CHARACTERS.length;
            selectCharacter(prev, CHARACTERS[prev].lines.length - 1);
        }
    }

    /* ---------------- 开关 ---------------- */
    function setAutoPlay(on) {
        autoPlay = on;
        const btn = $('autoBtn');
        btn.classList.toggle('on', autoPlay);
        btn.querySelector('.label').textContent = autoPlay ? '自动连播中' : '自动连播';
        btn.querySelector('.ico').textContent = autoPlay ? '❚❚' : '▶';

        if (autoPlay) {
            showLine(lineIndex); // 从当前句重新开始，进入连播
        } else {
            clearTimeout(advanceTimer);
            advanceTimer = null;
        }
    }

    function setVoice(on, silent) {
        voiceOn = on;
        const btn = $('voiceBtn');
        btn.classList.toggle('on', voiceOn);
        btn.querySelector('.label').textContent = voiceOn ? '语音朗读 · 开' : '语音朗读 · 关';

        if (voiceOn) {
            // 打开时把当前这句读一遍（首次初始化时不读，避免和 showLine 重复）
            const ch = CHARACTERS[charIndex];
            if (!silent && !isTyping && ch && ch.lines[lineIndex]) {
                speak(ch.lines[lineIndex].text, null);
            }
        } else {
            cancelSpeech();
        }
    }

    function cycleSpeed() {
        const cur = SPEEDS.findIndex(function (s) { return s.value === speed; });
        const next = SPEEDS[(cur + 1) % SPEEDS.length];
        speed = next.value;
        $('speedBtn').textContent = '语速 · ' + next.label;

        // 立即用新语速重读当前句
        const ch = CHARACTERS[charIndex];
        if (voiceOn && ch && ch.lines[lineIndex]) {
            speak(ch.lines[lineIndex].text, null);
        }
    }

    /* ---------------- 事件绑定 ---------------- */
    function bind() {
        $('prevBtn').addEventListener('click', goPrev);
        $('nextBtn').addEventListener('click', goNext);
        $('replayBtn').addEventListener('click', function () {
            showLine(lineIndex);
        });
        $('autoBtn').addEventListener('click', function () { setAutoPlay(!autoPlay); });
        $('voiceBtn').addEventListener('click', function () { setVoice(!voiceOn); });
        $('speedBtn').addEventListener('click', cycleSpeed);

        document.addEventListener('keydown', function (e) {
            if (e.key === 'ArrowRight') { e.preventDefault(); goNext(); }
            else if (e.key === 'ArrowLeft') { e.preventDefault(); goPrev(); }
            else if (e.key === ' ') { e.preventDefault(); goNext(); }
            else if (e.key === 'r' || e.key === 'R') { showLine(lineIndex); }
        });

        // 首次交互后浏览器才允许发声
        const unlock = function () {
            if (gestureReady) return;
            gestureReady = true;
            const tip = $('voiceTip');
            if (tip) tip.classList.add('hide');

            // 有些浏览器会拦截「非用户手势」的发声：若此刻并没有在念，就补读一次
            if (voiceOn && 'speechSynthesis' in window) {
                const busy = window.speechSynthesis.speaking || window.speechSynthesis.pending;
                const ch = CHARACTERS[charIndex];
                if (!busy && ch && ch.lines[lineIndex]) {
                    speak(ch.lines[lineIndex].text, null);
                }
            }
        };
        window.addEventListener('pointerdown', unlock, { once: true });
        window.addEventListener('keydown', unlock, { once: true });

        // 离开页面时停止发声
        window.addEventListener('beforeunload', function () {
            cancelSpeech();
        });
    }

    /* ---------------- 启动 ---------------- */
    function init() {
        renderRoster();

        // 支持 story.html?c=nezha 直达指定人物
        let startIndex = 0;
        try {
            const params = new URLSearchParams(window.location.search);
            const id = params.get('c');
            if (id) {
                const found = CHARACTERS.findIndex(function (c) { return c.id === id; });
                if (found >= 0) startIndex = found;
            }
        } catch (e) { /* noop */ }

        bind();
        setVoice(true, true); // 静默初始化，实际朗读交给 selectCharacter
        $('speedBtn').textContent = '语速 · 中';

        // 进入页面先停一下，让入场动画走完再开读
        setTimeout(function () {
            selectCharacter(startIndex, 0);
        }, 260);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
