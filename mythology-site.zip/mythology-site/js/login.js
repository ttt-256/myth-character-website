/* ============================================================
   登录 / 注册交互
   ------------------------------------------------------------
   沿用原有的账号方案：
     localStorage.userList  —— { "用户名": "密码" }  注册表
     localStorage.loginUser —— "当前登录用户名"
   登录成功后跳转 index.html（原示例里的 home.html 即本站首页）
   ============================================================ */
(function () {
    'use strict';

    var $ = function (id) { return document.getElementById(id); };

    var loginForm = $('loginForm');
    var registerForm = $('registerForm');
    var tabLogin = $('tabLogin');
    var tabRegister = $('tabRegister');

    /* ---------------- 提示 ---------------- */
    function clearMsg() {
        for (var i = 0; i < arguments.length; i++) {
            var el = arguments[i];
            if (!el) continue;
            el.textContent = '';
            el.classList.remove('ok');
        }
    }

    function say(el, text, ok) {
        if (!el) return;
        el.textContent = text;
        el.classList.toggle('ok', !!ok);
    }

    /* ---------------- 本地存储可用性 ---------------- */
    /* 隐私模式 / 禁用 Cookie 时，localStorage 读写会直接抛错，
       不先检测的话注册和登录都会「静默失败」，用户看不出原因 */
    function isLocalStorageAvailable() {
        try {
            var key = '__test_storage__';
            window.localStorage.setItem(key, key);
            window.localStorage.removeItem(key);
            return true;
        } catch (e) {
            return false;
        }
    }

    /* ---------------- 账号表 ---------------- */
    function readUsers() {
        try {
            return JSON.parse(window.localStorage.getItem('userList') || '{}') || {};
        } catch (e) {
            return {};
        }
    }

    /* ---------------- 面板切换 ---------------- */
    var showingLogin = true;

    function showLogin() {
        showingLogin = true;
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
        tabLogin.classList.add('active');
        tabRegister.classList.remove('active');
        tabLogin.setAttribute('aria-selected', 'true');
        tabRegister.setAttribute('aria-selected', 'false');
        clearMsg($('msg'), $('msg2'));
    }

    function showRegister() {
        showingLogin = false;
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
        tabRegister.classList.add('active');
        tabLogin.classList.remove('active');
        tabLogin.setAttribute('aria-selected', 'false');
        tabRegister.setAttribute('aria-selected', 'true');
        clearMsg($('msg'), $('msg2'));
    }

    /* ---------------- 注册 ---------------- */
    function register() {
        var user = $('regUser').value.trim();
        var pwd = $('regPwd').value.trim();
        var pwd2 = $('regPwd2').value.trim();
        var msgDom = $('msg2');

        if (!isLocalStorageAvailable()) {
            say(msgDom, '浏览器禁用了本地存储，请开启Cookie后重试');
            return;
        }

        if (!user || !pwd) { say(msgDom, '用户名密码不能为空'); return; }
        if (pwd !== pwd2) { say(msgDom, '两次密码不一致'); return; }

        var userList = readUsers();
        if (userList[user]) { say(msgDom, '用户名已存在'); return; }

        userList[user] = pwd;
        try {
            window.localStorage.setItem('userList', JSON.stringify(userList));
        } catch (e) {
            say(msgDom, '浏览器禁用了本地存储，无法注册');
            return;
        }

        say(msgDom, '注册成功！请登录', true);

        // 清空注册表单，把用户名带到登录框
        $('regUser').value = '';
        $('regPwd').value = '';
        $('regPwd2').value = '';
        $('loginUser').value = user;

        // 稍后自动切到登录面板
        setTimeout(function () {
            showLogin();
            say($('msg'), '请使用刚注册的账号登录', true);
            $('loginPwd').focus();
        }, 1000);
    }

    /* ---------------- 登录 ---------------- */
    function login() {
        var user = $('loginUser').value.trim();
        var pwd = $('loginPwd').value.trim();
        var msgDom = $('msg');

        if (!isLocalStorageAvailable()) {
            say(msgDom, '浏览器禁用了本地存储，请开启Cookie');
            return;
        }

        var userList = readUsers();
        if (!user || !pwd) { say(msgDom, '用户名密码不能为空'); return; }
        if (!userList[user]) { say(msgDom, '用户不存在'); return; }
        if (userList[user] !== pwd) { say(msgDom, '密码错误'); return; }

        try {
            window.localStorage.setItem('loginUser', user);
        } catch (e) {
            say(msgDom, '浏览器禁用了本地存储，无法登录');
            return;
        }

        say(msgDom, '登录成功，正在进入首页…', true);

        var btn = loginForm.querySelector('.auth-submit');
        if (btn) btn.disabled = true;

        setTimeout(function () {
            window.location.href = 'index.html';
        }, 600);
    }

    /* ---------------- 事件绑定 ---------------- */
    tabLogin.addEventListener('click', showLogin);
    tabRegister.addEventListener('click', showRegister);

    loginForm.addEventListener('submit', function (e) {
        e.preventDefault();
        login();
    });

    registerForm.addEventListener('submit', function (e) {
        e.preventDefault();
        register();
    });

    // 兼容原来内联 onclick 的调用方式
    window.isLocalStorageAvailable = isLocalStorageAvailable;
    window.showLogin = showLogin;
    window.showRegister = showRegister;
    window.login = login;
    window.register = register;

    /* ---------------- 已登录则给个直达提示 ---------------- */
    if (window.MythoAuth && window.MythoAuth.isLoggedIn()) {
        var note = document.querySelector('.auth-note');
        if (note) {
            var tip = document.createElement('p');
            tip.className = 'auth-msg ok';
            tip.style.marginTop = '0';
            tip.innerHTML = '当前已登录：<b>' + window.MythoAuth.getUser() +
                '</b> · <a href="index.html" style="color:inherit;text-decoration:underline">直接进入首页 →</a>';
            note.parentNode.insertBefore(tip, note);
        }
    }

    // 进页面直接聚焦
    if (showingLogin) {
        setTimeout(function () { $('loginUser').focus(); }, 120);
    }
})();
