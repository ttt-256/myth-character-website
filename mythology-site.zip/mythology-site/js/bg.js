/* ============================================================
   背景粒子：缓缓上浮的赤金火星 + 微光
   纯 Canvas 实现，跟随窗口尺寸，几乎不占性能
   ============================================================ */
(function () {
    const canvas = document.getElementById('bgCanvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let W = 0;
    let H = 0;
    let dpr = 1;
    let particles = [];
    let rafId = null;

    const reduceMotion = window.matchMedia &&
        window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function resize() {
        dpr = Math.min(window.devicePixelRatio || 1, 2);
        W = window.innerWidth;
        H = window.innerHeight;
        canvas.width = Math.floor(W * dpr);
        canvas.height = Math.floor(H * dpr);
        canvas.style.width = W + 'px';
        canvas.style.height = H + 'px';
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        seed();
    }

    function seed() {
        // 密度跟随屏幕面积，移动端自动减少
        const count = Math.max(26, Math.min(90, Math.round((W * H) / 22000)));
        particles = [];
        for (let i = 0; i < count; i++) {
            particles.push(makeParticle(true));
        }
    }

    function makeParticle(spread) {
        const warm = Math.random() > 0.42; // 一部分金色，一部分赤红
        return {
            x: Math.random() * W,
            y: spread ? Math.random() * H : H + Math.random() * 40,
            r: Math.random() * 1.9 + 0.5,
            vy: -(Math.random() * 0.34 + 0.09),
            vx: (Math.random() - 0.5) * 0.16,
            alpha: Math.random() * 0.5 + 0.15,
            phase: Math.random() * Math.PI * 2,
            speed: Math.random() * 0.014 + 0.005,
            color: warm ? '255, 205, 110' : '255, 90, 70'
        };
    }

    function draw() {
        ctx.clearRect(0, 0, W, H);

        for (let i = 0; i < particles.length; i++) {
            const p = particles[i];
            p.y += p.vy;
            p.x += p.vx;
            p.phase += p.speed;

            const twinkle = 0.62 + Math.sin(p.phase) * 0.38;
            const a = p.alpha * twinkle;

            // 光晕
            const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 5.2);
            grad.addColorStop(0, 'rgba(' + p.color + ',' + a.toFixed(3) + ')');
            grad.addColorStop(1, 'rgba(' + p.color + ',0)');
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r * 5.2, 0, Math.PI * 2);
            ctx.fill();

            // 核心
            ctx.fillStyle = 'rgba(255,245,225,' + (a * 0.9).toFixed(3) + ')';
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r * 0.55, 0, Math.PI * 2);
            ctx.fill();

            // 出界重生
            if (p.y < -30 || p.x < -40 || p.x > W + 40) {
                particles[i] = makeParticle(false);
            }
        }

        rafId = requestAnimationFrame(draw);
    }

    function start() {
        if (rafId !== null) return;
        rafId = requestAnimationFrame(draw);
    }

    function stop() {
        if (rafId === null) return;
        cancelAnimationFrame(rafId);
        rafId = null;
    }

    window.addEventListener('resize', resize);

    // 页面不可见时暂停，省电
    document.addEventListener('visibilitychange', function () {
        if (document.hidden) stop();
        else start();
    });

    resize();

    if (reduceMotion) {
        // 静态渲染一帧即可
        for (let i = 0; i < particles.length; i++) {
            const p = particles[i];
            ctx.fillStyle = 'rgba(' + p.color + ',' + p.alpha.toFixed(3) + ')';
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fill();
        }
        return;
    }

    start();
})();
