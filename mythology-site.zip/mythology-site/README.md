# 上古纪事 · 神话人物志

一个纯前端、零依赖的中国上古神话人物展示站点：登录后进入首页，挑选人物，先读一段**逐字浮现**的人物故事，再进入**对话页**听人物逐字说话（可选语音朗读）。

## 站点结构

```
登录页  →  首页  →  人物馆  →  人物故事页  →  人物对话页
login    index    characters   nezha/wukong…   story?c=<id>
```

| 页面 | 文件 | 说明 |
| --- | --- | --- |
| 登录 / 注册 | `login.html` | 双 Tab，账号存于浏览器 localStorage；支持可选的通行密钥登录（见下文） |
| 首页 | `index.html` | 红光标题、开始探索 / 关于本志 / 退出，底部六位人物快捷入口 |
| 人物馆 | `characters.html` | 六张毛玻璃卡片，点击进入该人物故事页 |
| 人物故事 | `nezha.html` 等六个 | 头像 + 副标题 + 逐字故事，读完弹出「重读 / 返回 / 进入对话」 |
| 人物对话 | `story.html?c=<id>` | 左侧人物名录，右侧逐字台词 + 浏览器语音朗读 |

## 目录

```
.
├── index.html          首页
├── login.html          登录 / 注册
├── characters.html     人物馆（第二页）
├── story.html          人物对话页
├── nezha.html          哪吒 · 故事页
├── wukong.html         孙悟空 · 故事页
├── yangjian.html       杨戬 · 故事页
├── change.html         嫦娥 · 故事页
├── kuafu.html          夸父 · 故事页
├── jingwei.html        精卫 · 故事页
├── css/
│   ├── style.css       首页 / 对话页
│   ├── login.css       登录页
│   ├── characters.css  人物馆（每人一套主题色）
│   └── tale.css        故事页（六页共用，颜色由 CSS 变量驱动）
├── js/
│   ├── auth.js         登录态读写 + 页面守卫
│   ├── login.js        登录 / 注册交互
│   ├── passkey.js      通行密钥登录（可选，未配置接口时自动隐藏）
│   ├── bg.js           首页 Canvas 火星粒子背景
│   ├── index.js        首页交互
│   ├── characters.js   对话页人物数据（台词、标签、主题色）
│   ├── story.js        对话页逐字打字机 + 语音朗读
│   ├── select.js       人物馆交互（用户名、退出、数字键 1-6）
│   ├── tales.js        六位人物故事全文（唯一文本来源）
│   └── tale.js         故事页逐字浮现 + 头像更换
└── assets/
    ├── avatar-*.svg    占位头像（国风纹样 + 名字单字）
    └── avatars/        故事页 140px 头像位，放 <人物id>.jpg 即自动生效
```

## 本地运行

语音朗读（Web Speech API）在 `file://` 下部分浏览器会受限，建议起一个本地静态服务：

```bash
# 任选其一，在本目录下执行
python -m http.server 8766
npx serve .
```

然后打开 `http://127.0.0.1:8766/login.html`。

首次使用请先「注册」一个账号（用户名 + 两次密码），注册成功后会自动带回登录 Tab。

## 怎么改内容

**改人物台词**：`js/characters.js` 的 `CHARACTERS` 数组，每人 5 句 `{ text, note }`，对话页名录、进度点、翻页会自动适配。

**改人物故事**：`js/tales.js`，六个键对应六页，改文本即可，排版与交互不受影响。

**换头像**：
- 故事页顶部头像读 `assets/avatars/<人物id>.jpg`，放进去刷新即生效，缺图时自动退回 `assets/avatar-*.svg`
- 也可以在页面上点「更换头像」，但只存在当前浏览器（`localStorage`）
- 首页底部 / 登录页左侧的小头像在 `index.html`、`login.html` 里，直接改 `src`

**改主题色**：故事页的颜色全部是 `css/tale.css` 里 `body.bg-<人物>` 的 CSS 变量（`--accent` / `--title` / `--subtitle`）：
哪吒红橙、孙悟空金、杨戬冷青、嫦娥月白、夸父暮金、精卫青碧。

## 通行密钥登录（可选）

`js/passkey.js` 实现了 WebAuthn 通行密钥登录（含输入框自动填充的条件式调用）。
**默认关闭**：`CONFIG.apiBase` 为空时入口按钮整个隐藏，密码登录不受任何影响。

**启用**：把 `js/passkey.js` 顶部 `CONFIG.apiBase` 改成后端地址（如 `'/api'`），
或在引入脚本前设置 `window.PASSKEY_CONFIG = { apiBase: '/api' }`。

**后端接口契约**（前端已按此实现）：

```
POST {apiBase}/auth/passkey/options
  请求体：{}（不传用户名，走 discoverable credential）
  响应 200：PublicKeyCredentialRequestOptions（challenge 用 base64url，
            需含 rpId、timeout、userVerification）
  服务端应把 challenge 存入会话，供下一步比对

POST {apiBase}/auth/passkey/verify
  请求体：{ id, rawId, type, authenticatorAttachment,
            response: { clientDataJSON, authenticatorData, signature, userHandle },
            clientExtensionResults }   （均为 base64url）
  响应 200：{ "ok": true, "user": { "name": "用户名" } }
  响应 4xx：验证失败
```

要求与注意：
- **必须 HTTPS**（`localhost` 除外），`rpId` 必须等于站点域名（不带端口和协议）
- 前端请求均带 `credentials: 'include'`，跨域部署时后端要配 CORS 允许凭据
- **验签必须在服务端做**（校验 challenge、origin、rpId、签名计数），前端无法自查
- 验证成功后前端会把 `user.name` 写入 `localStorage.loginUser` 以通过本站门禁，
  同时服务端可按需下发会话 Cookie

后端选型建议：
1. **自建最小后端**：Node 20 + Express + [`@simplewebauthn/server`](https://simplewebauthn.dev/)，
   两个接口各几十行；部署在站点同域（或 `/api` 反代）最省心
2. **托管身份服务**：Clerk、Auth0 等原生支持 passkey，适合不想碰加密细节的场景
3. WorkBuddy 云服务的账号体系（邮箱 / 短信 / 微信登录）**不包含** WebAuthn，
   可以当普通登录用，但替代不了通行密钥

## 技术说明

- 纯静态站点，无构建、无框架、无第三方依赖，直接用浏览器打开即可运行
- 逐字效果基于 `setTimeout` 分段写入；语音朗读用浏览器自带 `speechSynthesis`（中文音色取决于系统语音包）
- 登录是**前端门禁**：账号密码以明文存在浏览器 `localStorage`，仅用于演示与本地体验，**不要使用真实常用密码**。要做真实鉴权需要后端或同域的会话校验。

## 浏览器建议

Chrome / Edge 最新版。语音朗读需要用户先与页面交互过一次（浏览器自动播放策略），页面内有提示条。
